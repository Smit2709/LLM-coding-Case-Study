# Palau IMF PDF-to-Dashboard — execution notes
1. Open the accompanying .ipynb in Google Colab.
2. Run setup cells, supply a Gemini API key securely and upload the assigned Palau IMF report.
3. Run all cells and check the output/ figures and evaluation scores.
4. Inspect source tables (PDF p5 and p32) and manually verify AI-generated claims.
5. Submit an accessible Colab notebook link or public GitHub code as requested by the assignment.

Input: IMF Country Report 26/22, Republic of Palau, 2025 Article IV Consultation (Jan 2026).
Output: data/*.json, summaries/*.json, evaluation/*.json, rag/*.json, figures/*.png.
Key limitations: commercial-bank table excludes NDBP; unavailable/inapplicable metrics use -1.0;
LLM-as-a-Judge does not replace human verification; external API use may be billed.
